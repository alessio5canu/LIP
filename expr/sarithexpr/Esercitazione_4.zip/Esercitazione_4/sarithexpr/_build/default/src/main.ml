open Ast

type exprval = Bool of bool | Nat of int
type exprtype = BoolT | NatT
exception TypeError of string;;

let string_of_val = function
  Bool b -> if b then "true" else "false"
| Nat n -> string_of_int n
;;

let string_of_type = function
    BoolT-> "BoolT"
  | NatT -> "NatT"
;;

let rec string_of_expr = function
    True -> "True"
  | False -> "False"
  | If(e0,e1,e2) -> "If(" ^ (string_of_expr e0) ^ "," ^ (string_of_expr e1) ^ "," ^ (string_of_expr e2) ^ ")"
  | Not(e1) -> "not(" ^ (string_of_expr e1) ^ ")"
  | And(e1,e2) -> "And(" ^ (string_of_expr e1) ^ "," ^ (string_of_expr e2) ^ ")"	
  | Or(e1,e2) -> "Or(" ^ (string_of_expr e1) ^ "," ^ (string_of_expr e2) ^ ")"
  | Zero -> "0"
  | Succ(e1) -> "Succ(" ^ (string_of_expr e1) ^ ")"
  | Pred(e1) -> "Pred(" ^ (string_of_expr e1) ^ ")"
  | IsZero(e1) -> "IsZero(" ^ (string_of_expr e1) ^ ")"
;;

let parse (s : string) : expr =
  let lexbuf = Lexing.from_string s in
  let ast = Parser.prog Lexer.read lexbuf in
  ast

exception NoRuleApplies
  
let rec is_nv = function
    Zero -> true
  | Succ(e) -> is_nv e
  | _ -> false
  
let rec trace1 = function
    If(True,e1,_) -> e1
  | If(False,_,e2) -> e2
  | If(e0,e1,e2) -> let e0' = trace1 e0 in If(e0',e1,e2)
  | Not(True) -> False
  | Not(False) -> True
  | Not(e1) -> let e1' = trace1 e1 in Not(e1')
  | And(False,_) -> False
  | And(True,e1) -> e1
  | And(e1,e2) -> let e1' = trace1 e1 in And(e1',e2)
  | Or(True,_) -> True
  | Or(False,e1) -> e1
  | Or(e1,e2) -> let e1' = trace1 e1 in Or(e1',e2)
  | Succ(e1) -> let e1' = trace1 e1 in Succ(e1')
  | Pred(Zero) -> raise NoRuleApplies
  | Pred(Succ(e1)) when is_nv e1 -> e1
  | Pred(e1) -> let e1' = trace1 e1 in Pred(e1')
  | IsZero(Zero) -> True
  | IsZero(Succ(e1)) when is_nv e1 -> False
  | IsZero(e1) -> let e1' = trace1 e1 in IsZero(e1')
  | _ -> raise NoRuleApplies
;;

let rec trace e = try
    let e' = trace1 e
    in e::(trace e')
  with NoRuleApplies -> [e]
;;

let unwrapBool x = 

match x with
|True -> true
|False -> false
|_ -> failwith("x non è bool!")
;;

let unwrapNat x = 

match x with
|Nat x -> x
|_ -> failwith("x non è int!")
;;

let rec typecheck = function 
| True -> BoolT
| False -> BoolT
| Zero -> NatT 
| Not(e1) -> if(typecheck e1 == BoolT) then BoolT else raise(TypeError ("Errore! " ^ (string_of_expr e1) ^ " ha tipo " ^ string_of_type(typecheck e1) ^ ", ma deve essere di tipo BoolT"))
| And(e1,e2) -> if (typecheck e1 == BoolT) && (typecheck e2 == BoolT) then BoolT else raise(TypeError ("Errore! " ^ (string_of_expr e1) ^ " ha tipo " ^ string_of_type(typecheck e1) ^ " e " ^ (string_of_expr e2) ^ " ha tipo " ^ string_of_type(typecheck e2) ^", ma devono essere di tipo BoolT"))
| Or(e1,e2) -> if (typecheck e1 == BoolT) && (typecheck e2 == BoolT) then BoolT else raise(TypeError ("Errore! " ^ (string_of_expr e1) ^ " ha tipo " ^ string_of_type(typecheck e1) ^ " e " ^ (string_of_expr e2) ^ " ha tipo " ^ string_of_type(typecheck e2) ^", ma devono essere di tipo BoolT"))
| IsZero(e1) -> if (typecheck e1 == NatT) then NatT else raise(TypeError ("Errore! " ^ (string_of_expr e1) ^ " ha tipo " ^ string_of_type(typecheck e1) ^ ", ma deve essere di tipo NatT"))
| Succ(e1) -> if (typecheck e1 == NatT) then NatT else raise(TypeError ("Errore! " ^ (string_of_expr e1) ^ " ha tipo " ^ string_of_type(typecheck e1) ^ ", ma deve essere di tipo NatT"))
| Pred(e1) -> if (typecheck e1 == NatT) then NatT else raise(TypeError ("Errore! " ^ (string_of_expr e1) ^ " ha tipo " ^ string_of_type(typecheck e1) ^ ", ma deve essere di tipo NatT"))
| If(e1,e2,e3) -> if (typecheck e1 == BoolT) && (typecheck e2 == typecheck e3) then typecheck e2 else raise(TypeError ("Errore! " ^ (string_of_expr e1) ^ " ha tipo " ^ string_of_type(typecheck e1) ^ " , " ^ (string_of_expr e2) ^ " ha tipo " ^ string_of_type(typecheck e2) ^ " e " ^ (string_of_expr e3) ^ " ha tipo " ^ string_of_type(typecheck e3) ^ ", ma e1 deve essere di tipo BoolT e e2,e3 devono essere dello stesso tipo"))
;;

let rec eval = function
    True -> Bool true
  | False -> Bool false
  | If(e0,e1,e2) -> if (typecheck e0 == BoolT) then (if unwrapBool(e0) then eval e1 else eval e2) else Bool false
  | Not(e1) -> if (typecheck e1 == BoolT) then Bool(not(unwrapBool(e1))) else Bool false
  | And(e1,e2) -> if (typecheck e1 == BoolT) && (typecheck e2 == BoolT) then Bool(unwrapBool(e1) && unwrapBool(e2)) else Bool false
  | Or(e1,e2) -> if (typecheck e1 == BoolT) && (typecheck e2 == BoolT) then Bool(unwrapBool(e1) || unwrapBool(e2)) else Bool false
  | Zero -> Nat 0
  | IsZero(e1) -> if (typecheck e1 == BoolT) then Bool(eval e1 = Nat 0) else Bool false
  | Succ(e1) -> if (typecheck e1 == NatT) then Nat(unwrapNat(eval e1) + 1) else Bool false
  | Pred(e1) -> if (typecheck e1 == NatT) then (if unwrapNat(eval e1) = 0 then failwith("Non è definito!") else Nat(unwrapNat(eval e1) - 1)) else Bool false

;;